package com.example.common.model.fraud;
import lombok.*;
@Getter @Builder @NoArgsConstructor @AllArgsConstructor
public class FraudResultData { private String score; private String decision; }
