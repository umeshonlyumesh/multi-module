package com.example.common.model.qualification;
import lombok.*;
@Getter @Builder @NoArgsConstructor @AllArgsConstructor
public class EnrichmentData { private String customerSegment; private String kycLevel; }
